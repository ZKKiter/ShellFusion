from conf.config import Config

conf = Config()
