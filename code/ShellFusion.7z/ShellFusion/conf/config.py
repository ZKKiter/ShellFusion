import json
import os

"""
Two different ways for obtaining the current directory path:
1) os.getcwd() vs. 2) os.path.dirname(os.path.realpath(__file__))
see: https://blog.csdn.net/cyjs1988/article/details/77839238/
"""
config_json = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'config.json')


class Config:

    def __init__(self):
        with open(config_json, 'r') as f:
            content = f.read()
        config = json.loads(content)
        self.so_dir = config['so_dir']
        self.askubuntu_dir = config['askubuntu_dir']
        self.superuser_dir = config['superuser_dir']
        self.unixlinux_dir = config['unixlinux_dir']
        self.tldr_dir = config['tldr_dir']
        self.experiment_dir = config['experiment_dir']
        self.ubuntu_mp_url = config['ubuntu_manualpage_url']

        self.exp_posts_dir = self.experiment_dir + '/posts'
        self.exp_models_dir = self.experiment_dir + '/models'
        self.exp_manual_dir = self.experiment_dir + '/manual'
        self.exp_tldr_dir = self.experiment_dir + '/tldr'
        self.exp_evaluation_dir = self.experiment_dir + '/evaluation'
